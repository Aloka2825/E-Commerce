import React, { useEffect, useState } from "react";


const UserOptions = ({ user, openSpeedDial, setOpenSpeedDial }) => {
  const handleSpeedDialOpen = () => {
    setOpenSpeedDial(true);
  };

  const handleSpeedDialClose = () => {
    setOpenSpeedDial(false);
  };



  return (
    <>
      
    </>
  );
};

export default UserOptions;
